<form action="" method="POST" class="form-inline float-left" id="searchForm">
    <?php echo csrf_field(); ?>
    <select class="form-control form-control-sm mr-sm-2 mb-2" name="type" id="search_type">
        <option value="">Select a type</option>
        <option value="1" <?php if($type == 1): ?> selected <?php endif; ?>>Expense</option>
        <option value="2" <?php if($type == 2): ?> selected <?php endif; ?>>Incoming</option>
        <option value="3" <?php if($type == 3): ?> selected <?php endif; ?>>Transfer</option>
    </select>
    <input type="text" class="form-control form-control-sm mr-sm-2 mb-2" name="user" id="search_user" value="<?php echo e($user); ?>" placeholder="Username">
    <select class="form-control form-control-sm mr-sm-2 mb-2" name="account" id="search_account">
        <option value="">Select an account</option>
        <?php $__currentLoopData = $accountgroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accountgroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <optgroup label="<?php echo e($accountgroup->name); ?>">
                <?php $__currentLoopData = $accountgroup->accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>" data-icon="wallet" <?php if($account == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>                                            
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </optgroup>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>      
    </select>
    <select class="form-control form-control-sm mr-sm-2 mb-2" name="category" id="search_category">
        <option value="">Select a category</option>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>" <?php if($category == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <input type="text" class="form-control form-control-sm mr-sm-2 mb-2" name="period" id="period" autocomplete="off" value="<?php echo e($period); ?>" placeholder="Timestamp" style="max-width:170px;">
    <button type="submit" class="btn btn-sm btn-primary mb-2"><i class="icon-search4"></i>&nbsp;&nbsp;Search</button>
    <button type="button" class="btn btn-sm btn-info mb-2 ml-1" id="btn-reset"><i class="icon-eraser"></i>&nbsp;&nbsp;Reset</button>
</form><?php /**PATH E:\2019-Jun\Alzex\Alzex\resources\views/transaction/filter.blade.php ENDPATH**/ ?>