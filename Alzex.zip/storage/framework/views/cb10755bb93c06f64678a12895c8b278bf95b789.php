<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('master/global_assets/js/plugins/daterangepicker/daterangepicker.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php
        $role = Auth::user()->role->slug;
    ?>
    <div class="content-wrapper">
        <div class="page-header page-header-light">
            <div class="page-header-content header-elements-md-inline">
                <div class="page-title d-flex">
                    <h4><i class="icon-arrow-left52 mr-2"></i> <span class="font-weight-semibold">Home</span> - Transaction</h4>
                    <a href="index.html#" class="header-elements-toggle text-default d-md-none"><i class="icon-more"></i></a>
                </div>
                <div class="header-elements d-flex">
                    <div class="d-flex justify-content-center">
                        <div class="btn-group justify-content-center">
                            <a href="#" class="btn bg-primary-400 dropdown-toggle" data-toggle="dropdown"><i class="icon-wallet"></i>  Account Balance</a>
                            <div class="dropdown-menu">
                                <?php $__currentLoopData = $accountgroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accountgroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="dropdown-header dropdown-header-highlight"><?php echo e($accountgroup->name); ?></div>
                                    <?php $__currentLoopData = $accountgroup->accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                         
                                        <div class="dropdown-item"><div class="flex-grow-1"><?php echo e($item->name); ?></div><div class=""><?php echo e($item->balance); ?></div></div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <div class="dropdown-divider"></div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="breadcrumb-line breadcrumb-line-light header-elements-md-inline">
                <div class="d-flex">
                    <div class="breadcrumb">
                        <a href="<?php echo e(url('/')); ?>" class="breadcrumb-item"><i class="icon-home2 mr-2"></i> Home</a>
                        <span class="breadcrumb-item active">Transaction</span>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="content">
            <div class="card">
                <div class="card-header">
                    <?php echo $__env->make('transaction.filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <a href="<?php echo e(route('transaction.create')); ?>" class="btn btn-primary btn-sm float-right" id="btn-add"><i class="icon-plus-circle2 mr-2"></i> Add New</a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr class="bg-blue">
                                    <th style="width:30px;">#</th>
                                    <th>Type</th>
                                    <th>User</th>
                                    <th>Category</th>
                                    <th>Amount</th>
                                    <th>Withdraw From</th>
                                    <th>Target Account</th>
                                    <th>Date</th>
                                    <th>Description</th>
                                    <?php if($role == 'admin'): ?>
                                        <th>Action</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>                                
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e((($data->currentPage() - 1 ) * $data->perPage() ) + $loop->iteration); ?></td>
                                        <td class="type">
                                            <?php
                                                $types = array('Expense', 'Incoming', 'Transfer');
                                            ?>
                                            <?php echo e($types[$item->type-1]); ?>

                                        </td>
                                        <td class="user"><?php echo e($item->user->name); ?></td>
                                        <td class="category"><?php echo e($item->category->name); ?></td>
                                        <td class="amount"><?php echo e($item->amount); ?></td>
                                        <td class="from"><?php if(isset($item->account->name)): ?><?php echo e($item->account->name); ?><?php endif; ?></td>
                                        <td class="to"><?php if(isset($item->target->name)): ?><?php echo e($item->target->name); ?><?php endif; ?></td>
                                        <td class="date"><?php echo e(date('Y-m-d', strtotime($item->timestamp))); ?></td>
                                        <td class="description">
                                            <?php echo e($item->description); ?>

                                            <?php if($item->attachment != ""): ?>
                                                <a href="#" class="btn-attach" data-value="<?php echo e($item->attachment); ?>"><i class="icon-attachment"></i></a>
                                            <?php endif; ?>
                                        </td>
                                        <?php if($role == 'admin'): ?>
                                            <td class="py-1" style="min-width:130px;">
                                                <a href="#" class="btn bg-blue btn-icon rounded-round btn-edit" data-id="<?php echo e($item->id); ?>"  data-popup="tooltip" title="Edit" data-placement="top"><i class="icon-pencil7"></i></a>
                                                <a href="<?php echo e(route('transaction.delete', $item->id)); ?>" class="btn bg-danger text-pink-800 btn-icon rounded-round ml-2" data-popup="tooltip" title="Delete" data-placement="top" onclick="return window.confirm('Are you sure?')"><i class="icon-trash"></i></a>
                                            </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot class="text-danger text-center">
                                <tr>
                                    <td colspan="2">Total</td>
                                    <td colspan="3">Expenses : <?php echo e($expenses); ?></td>
                                    <td colspan="3">Incomes : <?php echo e($incomes); ?></td>
                                    <td colspan="2">Profit : <?php echo e($incomes - $expenses); ?></td>
                                </tr>
                            </tfoot>
                        </table>
                        <div class="clearfix mt-1">
                            <div class="float-left" style="margin: 0;">
                                <p>Total <strong style="color: red"><?php echo e($data->total()); ?></strong> Items</p>
                            </div>
                            <div class="float-right" style="margin: 0;">
                                <?php echo $data->appends(['user' => $user, 'category' => $category, 'type' => $type, 'account' => $account, ''])->links(); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>                
    </div>

    <div class="modal fade" id="attachModal">
        <div class="modal-dialog" style="margin-top:17vh">
            <div class="modal-content">
                <img src="" id="attachment" width="100%" height="600" alt="">
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('master/global_assets/js/plugins/daterangepicker/jquery.daterangepicker.min.js')); ?>"></script>
<script>
    $(document).ready(function () {
        $("#period").dateRangePicker({
            autoClose: false,
        });
        $(".btn-attach").click(function(e){
            e.preventDefault();
            let path = '<?php echo e(asset("/")); ?>' + $(this).data('value');
            $("#attachment").attr('src', path);
            $("#attachModal").modal();
        });
        $("#btn-reset").click(function(){
            $("#search_user").val('');
            $("#search_category").val('');
            $("#search_account").val('');
            $("#search_type").val('');
            $("#period").val('');
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\2019-Jun\Alzex\Alzex\resources\views/transaction/index.blade.php ENDPATH**/ ?>