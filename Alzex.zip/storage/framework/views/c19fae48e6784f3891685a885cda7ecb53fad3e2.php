<?php
    $page = config('site.page');
?>
<div class="sidebar sidebar-dark sidebar-main sidebar-expand-md">
    <div class="sidebar-mobile-toggler text-center">
        <a href="form_checkboxes_radios.html#" class="sidebar-mobile-main-toggle">
            <i class="icon-arrow-left8"></i>
        </a>
        Navigation
        <a href="form_checkboxes_radios.html#" class="sidebar-mobile-expand">
            <i class="icon-screen-full"></i>
            <i class="icon-screen-normal"></i>
        </a>
    </div>

    <div class="sidebar-content">
        <div class="sidebar-user">
            <div class="card-body">
                <div class="media">
                    <div class="mr-3">
                        <a href="#"><img src="<?php if(isset(Auth::user()->picture)): ?><?php echo e(asset(Auth::user()->picture)); ?> <?php else: ?> <?php echo e(asset('images/avatar128.png')); ?> <?php endif; ?>" width="38" height="38" class="rounded-circle" alt=""></a>
                    </div>
                    <div class="media-body">
                        <div class="media-title font-weight-semibold"><?php echo e(Auth::user()->name); ?></div>
                        <div class="font-size-xs opacity-50">
                            <i class="icon-user font-size-sm"></i> &nbsp;<?php echo e(Auth::user()->role->name); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card card-sidebar-mobile">
            <ul class="nav nav-sidebar" data-nav-type="accordion">
                <li class="nav-item"><a href="<?php echo e(route('home')); ?>" class="nav-link <?php if($page == 'home'): ?> active <?php endif; ?>"><i class="icon-home4"></i><span>Dashboard</span></a></li>
                <li class="nav-item"><a href="<?php echo e(route('transaction.index')); ?>" class="nav-link <?php if($page == 'transaction'): ?> active <?php endif; ?>"><i class="icon-cash3"></i><span>Transaction</span></a></li>
                <li class="nav-item"><a href="<?php echo e(route('account.index')); ?>" class="nav-link <?php if($page == 'account'): ?> active <?php endif; ?>"><i class="icon-credit-card"></i><span>Account</span></a></li>
                <li class="nav-item"><a href="<?php echo e(route('category.index')); ?>" class="nav-link <?php if($page == 'category'): ?> active <?php endif; ?>"><i class="icon-tree7"></i><span>Category</span></a></li>
                <li class="nav-item"><a href="<?php echo e(route('users.index')); ?>" class="nav-link <?php if($page == 'user'): ?> active <?php endif; ?>"><i class="icon-users2"></i><span>User</span></a></li>
                
            </ul>
        </div>
    </div>    
</div><?php /**PATH E:\2019-Jun\Alzex\Alzex\resources\views/layouts/aside.blade.php ENDPATH**/ ?>