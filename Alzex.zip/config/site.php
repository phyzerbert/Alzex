<?php

return [

    'page' => 'home',

];
